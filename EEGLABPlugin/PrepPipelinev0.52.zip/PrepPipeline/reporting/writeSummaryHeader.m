function writeSummaryHeader(sumFile, summaryHeader) 
    fprintf(sumFile, '\n<h2>%s</h2>', summaryHeader);
end
